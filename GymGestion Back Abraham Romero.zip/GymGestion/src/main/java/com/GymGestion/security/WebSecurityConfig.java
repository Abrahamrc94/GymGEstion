package com.GymGestion.security;



import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;

import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import com.GymGestion.security.common.SecurityConstants;
import com.GymGestion.security.filter.JWTAuthenticationFilter;
import com.GymGestion.security.filter.JWTAuthorizationFilter;
import com.GymGestion.security.model.UserRole;
import com.GymGestion.security.service.UserService;


@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter{

	 @Autowired
	 private JWTAuthorizationFilter jwtAuthorizationFilter;
	 
	@Autowired
	private UserService userService;
	
	@Autowired 
	private PasswordEncoder passWordEncoder;
	
	
	@Bean
	@Override
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}
		
	/*@Override
	public void configure(WebSecurity web) throws Exception {
		web.ignoring().anyRequest();
	}*/

	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		http.cors().and().csrf().disable().authorizeRequests()
			.antMatchers(HttpMethod.POST, SecurityConstants.SIGN_UP_URL).permitAll()
			.antMatchers(HttpMethod.POST, SecurityConstants.LOG_IN).permitAll()
			.antMatchers(HttpMethod.GET, "/customer/*").permitAll()
			.antMatchers(HttpMethod.PUT, "/customer/*").permitAll()
			.antMatchers(HttpMethod.GET, "/producto/*").permitAll()
			.antMatchers(HttpMethod.GET, "/pedido/*").permitAll()
			.antMatchers(HttpMethod.POST, "/pedido/*").permitAll()
			.antMatchers(HttpMethod.PUT, "/pedido/*").permitAll()
			.and()
			.addFilter(new JWTAuthenticationFilter(authenticationManagerBean()))
			.addFilterBefore(jwtAuthorizationFilter, BasicAuthenticationFilter.class)
		.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
	}



}
