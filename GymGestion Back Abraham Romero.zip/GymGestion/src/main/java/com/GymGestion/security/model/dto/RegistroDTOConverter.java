package com.GymGestion.security.model.dto;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.GymGestion.entity.Usuario;
import com.GymGestion.security.model.User;
import com.GymGestion.security.model.UserRole;
import com.GymGestion.security.repo.UserRepository;

@Component
public class RegistroDTOConverter {
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	private UserRepository userRepo;
	
	public User fromRegistroDTOToUser(RegistroDto dto) {
		User user  = new User();
		user.setUsername(dto.getNickname());
		user.setPassword(passwordEncoder.encode(dto.getPassword()));
		user.setRoles(Set.of(UserRole.USER));
		user.setCreateTime(LocalDateTime.now());
		user.setUpdateTime(LocalDateTime.now());
		user.setLastPasswordChange(LocalDateTime.now());
		user.setLocked(false);
		user.setEnabled(true);
		user.setAuthenticationAttempts(0);
		user.setPasswordPolicyExpDate(LocalDateTime.now().plusDays(180));
		return user;
		
	}
	
	public Usuario fromRegistroDtoToUsuario(RegistroDto dto) {
		
		Usuario usuario = new Usuario();
		usuario.setNombre(dto.getNombre());
		usuario.setApellidos(dto.getApellidos());
		usuario.setFecha_Proximo_Pago(LocalDate.now().plusMonths(1));
		usuario.setPuntos(5);
		User newUser = userRepo.findUserByUsername(dto.getNickname());
		usuario.setUser(newUser);
		
		return usuario;
		
	}
	
	public UserDTO fromUserToUserDTO(User user) {
		UserDTO dto = new UserDTO();
		dto.setUsername(user.getUsername());
		dto.setRoles(user.getRoles());
		return dto;
	}
	
}
