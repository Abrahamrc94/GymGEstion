package com.GymGestion.security.model;

public enum UserRole {

	USER, ADMIN
	
}
