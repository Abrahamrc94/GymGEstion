package com.GymGestion.security.service;

import javax.naming.AuthenticationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.GymGestion.entity.Usuario;
import com.GymGestion.repo.UsuarioRepository;
import com.GymGestion.security.model.User;
import com.GymGestion.security.model.dto.RegistroDTOConverter;
import com.GymGestion.security.model.dto.RegistroDto;
import com.GymGestion.security.model.dto.UserDTO;
import com.GymGestion.security.repo.UserRepository;

@Service("userService")
public class UserService implements UserDetailsService {
	
	@Autowired
	private UserRepository repository;
	
	@Autowired
	private UsuarioRepository usuarioRepo;
	
	@Autowired
	private RegistroDTOConverter converter;
	

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		return repository.findByUsername(username)
				.orElseThrow(()-> new UsernameNotFoundException("Username not found"));
	}
	
	
	
	public UserDetails loadUserById(Long idUser) throws AuthenticationException {
		return repository.findById(idUser)
				.orElseThrow(()-> new AuthenticationException("Id/username not found"));
	}	
	
	
	public UserDTO createNewUser(RegistroDto dto) {
		
		//Obtenemos el User y lo guardamos
		User nuevoUser = converter.fromRegistroDTOToUser(dto);
		repository.save(nuevoUser);
		
		
		//Obtenemos el Usuario y lo guardamos
		Usuario nuevoUsuario = converter.fromRegistroDtoToUsuario(dto);
		usuarioRepo.save(nuevoUsuario);
		return converter.fromUserToUserDTO(nuevoUser);
	}
	

}
