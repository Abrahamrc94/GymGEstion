package com.GymGestion.services;

import org.springframework.stereotype.Service;

import com.GymGestion.entity.Usuario;


@Service
public class UpdateService {

	public void updateUsuario (Usuario original, Usuario sent) {
		original.setNombre((sent.getNombre() == null) ? original.getNombre() : sent.getNombre());
		original.setApellidos((sent.getApellidos() == null) ? original.getApellidos() : sent.getApellidos());
		original.setPuntos((sent.getPuntos() == 0) ? original.getPuntos() : sent.getPuntos());
		//original.setFecha_Proximo_Pago((sent.getFecha_Proximo_Pago() == null) ? original.getFecha_Proximo_Pago() : sent.getFecha_Proximo_Pago());
		original.setFacturas((sent.getFacturas() == null) ? original.getFacturas() : sent.getFacturas());
		original.setEstado((sent.getEstado() == null) ? original.getEstado() : sent.getEstado());
	}
}
