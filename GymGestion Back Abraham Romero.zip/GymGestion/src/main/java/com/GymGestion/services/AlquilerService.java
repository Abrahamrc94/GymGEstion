package com.GymGestion.services;

public class AlquilerService {

}
