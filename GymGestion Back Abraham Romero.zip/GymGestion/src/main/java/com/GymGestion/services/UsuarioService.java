package com.GymGestion.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.GymGestion.entity.Estado;
import com.GymGestion.entity.Usuario;
import com.GymGestion.repo.UsuarioRepository;

@Service
public class UsuarioService {

	// Repositorios
	@Autowired
	private UsuarioRepository usuarioRepository;

	// Servicios
		@Autowired
		private UpdateService updateService;

	public UsuarioService(UsuarioRepository usuarioRepository) {
		this.usuarioRepository = usuarioRepository;

	}

	// Get de todos los usuarios
	public ResponseEntity<?> getUsuarios() {
		return ResponseEntity.status(HttpStatus.OK).body(usuarioRepository.findAll());
	}

	// Get para un usuario por id
	public Usuario getUsuarioById(Long id) {
		return usuarioRepository.findUsuarioByUsuarioId(id);

	}

	// Get de todos los usuarios por nombre
	public List<Usuario> getUsuarioOrderByNombre() {
		return usuarioRepository.findAllOrderedByNombre();
	}

	// Crear un nuevo usuario
	public Usuario saveUsuario(Usuario sent) {
		return usuarioRepository.save(sent);
	}

	// Actualziar un usuario
	public ResponseEntity<?> updateUsuario(Long id, Usuario sent) {
		Usuario c = usuarioRepository.findUsuarioByUsuarioId(id);
		ResponseEntity<?> response;
		if (c == null) {
			response = ResponseEntity.notFound().build();
		} else {
			updateService.updateUsuario(c, sent);
			response = ResponseEntity.ok(usuarioRepository.save(c));
		}
		return response;
	}

	// Borrar un usuario
	public void deleteUsuario(Long id) {
		usuarioRepository.deleteUsuarioByUsuarioId(id);
	}
	
	
	//Actualiza la fecha de pago de un usuario
	public ResponseEntity<?> updatePago(Long id, long mes) {
		Usuario c = usuarioRepository.findUsuarioByUsuarioId(id);
		ResponseEntity<?> response;
		if (c == null) {
			response = ResponseEntity.notFound().build();
		} else {
			if(c.getEstado()==Estado.INACTIVO) {
				c.setEstado(Estado.ACTIVO);
			}
			long puntos = c.getPuntos();
			long nuevosPuntos = (5*mes)+puntos;
			c.setFecha_Proximo_Pago(LocalDate.now().plusMonths(mes));
			c.setPuntos(nuevosPuntos);
			response = ResponseEntity.ok(usuarioRepository.save(c));
		}
		return response;
	
		
		
	}

	//Actualiza el estado a INACTIVO de todos los clientes cuya fecha de pago
	//lleve expirada más 7 días 
	public ResponseEntity<?> updateEstado() {
		Iterable<Usuario> usuarios = new ArrayList();
		
		usuarios = usuarioRepository.findAll();
		for(Usuario u: usuarios) {
			if(u.getFecha_Proximo_Pago().isBefore(LocalDate.now().minusDays(7))) {
				u.setEstado(Estado.INACTIVO);
				usuarioRepository.save(u);
			}
		}
		return ResponseEntity.ok("Estados actualizados");
	}

}
