package com.GymGestion.entity;

public enum Estado {

	ACTIVO, INACTIVO
}
