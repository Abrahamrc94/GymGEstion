package com.GymGestion.entity;

import java.io.Serializable;
import java.sql.Date;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
public class Factura implements Serializable{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long facturaId;
	private Date fecha;
	private double importe;
	
	@ManyToOne
	@JoinColumn(name = "usuarioId", foreignKey = @ForeignKey(name = "Usuario_IDFactura_FK"))
	@JsonIgnore
	private Usuario usuario;
	
	
	public Factura(Date fecha, double importe) {
		super();
		this.fecha = fecha;
		this.importe = importe;
	}


	public Date getFecha() {
		return fecha;
	}


	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}


	public double getImporte() {
		return importe;
	}


	public void setImporte(double importe) {
		this.importe = importe;
	}


	public Long getFacturaId() {
		return facturaId;
	}
		

	
	

}
