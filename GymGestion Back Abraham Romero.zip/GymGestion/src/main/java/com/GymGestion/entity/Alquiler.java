package com.GymGestion.entity;

import java.sql.Date;

import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Alquiler {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long alquilerId;
	private double precio;
	private Date fecha;
	private String tramoHorario;
	
	@ManyToOne
	@JoinColumn(name = "usuarioId", foreignKey = @ForeignKey(name = "Usuario_ID_FK"))
	@JsonIgnore
	private Usuario usuario;
	
	@ManyToOne
	@JoinColumn(name = "pistaId", foreignKey = @ForeignKey(name = "Pista_ID_FK"))
	@JsonIgnore
	private PistaPadel pista;

	public Alquiler(double precio, Date fecha, String tramoHorario, Usuario usuario, PistaPadel pista) {
		super();
		this.precio = precio;
		this.fecha = fecha;
		this.tramoHorario = tramoHorario;
		this.usuario = usuario;
		this.pista = pista;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public String getTramoHorario() {
		return tramoHorario;
	}

	public void setTramoHorario(String tramoHorario) {
		this.tramoHorario = tramoHorario;
	}

	public Usuario getUsuario() {
		return usuario;
	}

	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

	public PistaPadel getPista() {
		return pista;
	}

	public void setPista(PistaPadel pista) {
		this.pista = pista;
	}
	
	
	
	
}
