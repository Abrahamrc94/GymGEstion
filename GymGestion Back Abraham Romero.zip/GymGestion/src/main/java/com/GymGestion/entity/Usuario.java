package com.GymGestion.entity;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.GymGestion.security.model.User;
import com.GymGestion.security.model.UserRole;

@Entity
public class Usuario implements Serializable{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long usuarioId;
	@Column(nullable = false)
	private String nombre;
	private String apellidos;
	private long puntos;
	private LocalDate fecha_Proximo_Pago;
	@Enumerated(EnumType.ORDINAL)
	private Estado estado;

	
	@OneToMany(cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Factura> facturas;
	
	@OneToOne(cascade = CascadeType.ALL, orphanRemoval = true)
	@JoinColumn(name = "idUser", foreignKey = @ForeignKey(name = "FK_USUARIO_USER"))
	private User user;
	
	
	public Usuario(String nombre, String apellidos, int puntos, LocalDate fecha_Proximo_Pago) {
		super();
		this.nombre = nombre;
		this.apellidos = apellidos;
		this.puntos = puntos;
		this.fecha_Proximo_Pago = fecha_Proximo_Pago;
		this.facturas = new ArrayList<Factura>();
		this.estado = Estado.ACTIVO;
	}


	public Usuario() {
		// TODO Auto-generated constructor stub
		this.estado = Estado.ACTIVO;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getApellidos() {
		return apellidos;
	}


	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}


	public long getPuntos() {
		return puntos;
	}


	public void setPuntos(long puntos) {
		this.puntos = puntos;
	}


	public LocalDate getFecha_Proximo_Pago() {
		return fecha_Proximo_Pago;
	}


	public void setFecha_Proximo_Pago(LocalDate fecha) {
		this.fecha_Proximo_Pago = fecha;
	}

	public Long getUsuarioId() {
		return usuarioId;
	}

	public List<Factura> getFacturas() {
		return facturas;
	}


	public void setFacturas(List<Factura> facturas) {
		this.facturas = facturas;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	public Estado getEstado() {
		return estado;
	}


	public void setEstado(Estado estado) {
		this.estado = estado;
	}
	
}
	