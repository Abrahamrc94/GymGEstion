package com.GymGestion.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.GymGestion.entity.Usuario;
import com.GymGestion.security.model.User;


@Repository(value="UsuarioRepository")
public interface UsuarioRepository extends CrudRepository<Usuario, Integer>{

			// Get de un usuario por nombre
			public Usuario findUsuarioByNombre(String nombre);

			//Busca un usuario por id
			public Usuario findUsuarioByUsuarioId(Long id);
				
				
			// Get de todos los usuario ordenado por nombre
			@Query(value = "select * from usuario order by name", nativeQuery = true)
			public List<Usuario> findAllOrderedByNombre();
				
			//Borra un usuario
			public void deleteUsuarioByUsuarioId(Long id);
				
			// Esta query pretende obtener un usuario desde el username y la contraseña, se usa para el login.
			@Query(value = "SELECT * FROM usuario c WHERE c.username LIKE %?1% AND c.password LIKE %?2%", nativeQuery=true)
			Usuario findByUsernameAndPassword(String username, String password);
}
