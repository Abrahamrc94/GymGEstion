package com.GymGestion.controller;

public class AlquilerController {

}
