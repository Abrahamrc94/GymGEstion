package com.GymGestion.controller;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.GymGestion.entity.Usuario;
import com.GymGestion.services.UsuarioService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping
public class UsuarioController {

	// Creamos los servicios
	@Autowired
	private UsuarioService usuarioService;

	// Devuelve todos los usuarios
	@GetMapping("/usuario")
	public ResponseEntity<?> getUsuarios() {
		return usuarioService.getUsuarios();
	}

	// Devuelve usuarios ordenados segun el nombre
	@GetMapping("/usuario/nombres")
	public ResponseEntity<?> getUsuarioOrderByNombre() {
		return ResponseEntity.ok(usuarioService.getUsuarioOrderByNombre());
	}

	// Devuelve un usuario segun el id
	@GetMapping("/usuario/{id}")
	public ResponseEntity<?> getUsuarioId(@PathVariable Long id) {
		return ResponseEntity.ok(usuarioService.getUsuarioById(id));
	}

	// Crea un usuario
	@PostMapping("/usuario")
	public Usuario createUsuario(@RequestBody Usuario sent) {
		return usuarioService.saveUsuario(sent);
	}

	// Modifica un usuario PUT
	@PutMapping("/usuario/{id}")
	public ResponseEntity<?> updateUsuario(@PathVariable Long id, @RequestBody Usuario sent) {
		return usuarioService.updateUsuario(id, sent);
	}
	
	// Actualiza la fecha de pago y los puntos PUT
	@PutMapping("/usuario/pago/{id}")
	public ResponseEntity<?> updatePago(@PathVariable Long id, @RequestBody long mes) {
		return usuarioService.updatePago(id, mes);
		}
	
	//Actualiza el estado
	@PutMapping("/usuario/estado")
	public ResponseEntity<?> updateEstado() {
		return usuarioService.updateEstado();
			
	}

	// Borra un usuario
	@Transactional
	@DeleteMapping("/usuario/{id}")
	public void deleteUsuario(@PathVariable Long id) {
		usuarioService.deleteUsuario(id);
	}
}
