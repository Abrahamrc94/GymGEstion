import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AlquilerPistaPadelComponent } from './alquiler-pista-padel.component';

describe('AlquilerPistaPadelComponent', () => {
  let component: AlquilerPistaPadelComponent;
  let fixture: ComponentFixture<AlquilerPistaPadelComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AlquilerPistaPadelComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AlquilerPistaPadelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
