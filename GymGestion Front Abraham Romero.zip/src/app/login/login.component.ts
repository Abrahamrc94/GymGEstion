import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../interfaces/userInterface';
import { LoginService } from '../services/login.service'; 
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ErroresService } from '../services/errores.service';

@Component({
  selector: 'app-user-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  
  public form: FormGroup;
  public submitted = false;


  constructor(
    private formBuilder: FormBuilder, 
    private router: Router,
    private loginService: LoginService,
    private errorService: ErroresService) { }

  ngOnInit(): void {
    this.createForm()
  }

  createForm() {
    this.form = this.formBuilder.group({
      username: ['', [Validators.required,]],
      password: ['', [Validators.required]],
    });
  }

  onSubmit() {
    this.submitted = true;

    if (this.form.invalid) return;

    const user: User = this.form.value;

    this.loginService.login(user).subscribe((data) => {
      if(data != undefined && data != null) {
        localStorage.setItem('jwt', data);
        this.loginService.almacenaId(data);
        if(localStorage.getItem("jwt") != ""){
          this.errorService.LoginCorrecto('/home')
        }else{
          localStorage.clear();
        }
      }
    },
    error => {
      if(error != null){
        this.errorService.ErrorInesperado()
      }
    })
  }

  get f() {
    return this.form.controls;
  }

  public errorMessages = {
    email: [
      { type: 'required', message: 'The email is required' },
      { type: 'email', message: 'Must be a valid email' },
    ],
    password: [{ type: 'required', message: 'The password is required' }],
  };

}
