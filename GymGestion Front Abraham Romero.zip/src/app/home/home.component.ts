import { Component, OnInit } from '@angular/core';
import { from } from 'rxjs';
import Swal from 'sweetalert2';
import { Usuario } from '../interfaces/usuarioInterface';
import { UsuarioService } from '../services/usuario.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  filter = '';

  public showModal = false;

  public pa: number;

  public usuarios: Usuario[] = [];

  public Usuario: Usuario = {
    usuarioId: null,
    nombre: null,
    apellidos: null,
    puntos: null,
    fecha_Proximo_Pago: null,
    nickname: null,
    password: null,
    estado: null
  };

  constructor(public usuarioService: UsuarioService) { }

  ngOnInit(): void {
    this.getUsuarioList()
  }

  getUsuarioList() {
    this.usuarioService.getUsuarioList().subscribe(
      (resp) => {
        this.usuarios = resp;
      },
      (err) => {
        console.log(err);
      }
    );
  }

  openModal(usuario?: Usuario) {
    if(usuario) {
      this.Usuario = JSON.parse(JSON.stringify(usuario))
    }
    this.showModal = true;
  }



  closeModal(showModal: boolean) {
    this.Usuario = {
      usuarioId: null,
      nombre: null,
      apellidos: null,
      puntos: null,
      fecha_Proximo_Pago: null,
      nickname: null,
      password: null,
      estado: null
    }
    this.showModal = showModal;
  }

  updateUsuario(updateUsuario: Usuario) {
    const index = this.usuarios.findIndex(o => o.usuarioId == updateUsuario.usuarioId)

    if(index > -1) {
      this.usuarios.splice(index, 1, updateUsuario)
    } else {
      this.usuarios.push(updateUsuario)
    }
  }

  deleteUsuario(usuario: Usuario) {
    Swal.fire({
      icon: 'question',
      text: `¿Dar de baja a ${usuario.nombre} ${usuario.apellidos}?`,
      showCancelButton: true,
      cancelButtonText: 'Cancelar',
      cancelButtonColor: '#17a2b8',
      showConfirmButton: true,
      confirmButtonText: 'Eliminar',
      confirmButtonColor: '#dc3545'
    }).then((result) => {
      if(result.isConfirmed) {
        this.usuarioService.delete(usuario.usuarioId).subscribe(resp => {
        }, err => {
          console.log(err)
        })
      }
    })
    
  }
  


  UpdateEstados(){
    this.usuarioService.updateEstados()
  }
}
