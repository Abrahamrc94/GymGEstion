import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable, Subject } from 'rxjs';
import { User } from '../interfaces/userInterface';
import jwt_decode  from 'jwt-decode';

@Injectable({
    providedIn: 'root'
  })
  export class LoginService {

    public logStatusCustomer = new Subject<boolean>();
    public loggedStatus = this.logStatusCustomer.asObservable();
    public url = '';

    user: User={username:"", password:""}

    constructor(private http: HttpClient) { }


  /**Para realizar la peticion de autenticación del usuario */
  login(user: User): Observable<any> {
    return this.http.post(environment.loginUrl, user, { responseType: 'text'});
  }

  //Se usa para saber si hay un usuario Logado o no para CanActivate
  isloggedIn(url: string){
    const isLogged = localStorage.getItem('jwt');

    if(!isLogged){
      this.url = url
      return false;
    }
    return true;
  }


  almacenaId(token: string){
    const tokenDecodificado: any = jwt_decode(token);
    localStorage.setItem('id', tokenDecodificado.sub);
  }



  
  }