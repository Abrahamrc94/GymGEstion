import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { Usuario } from '../interfaces/usuarioInterface';
import { environment } from 'src/environments/environment';
import { Registro } from '../interfaces/registroInterface';
import jwt_decode  from 'jwt-decode';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {

  constructor(private router: Router, private http: HttpClient) {}


    //Obtiene los datos del usuario actual
    getUsuarioAutenticado(): Observable<Usuario>{
      return this.http.get<Usuario>(environment.apiUrl + '/usuario/' + localStorage.getItem('id'))
    }
  
    almacenaId(token: string){
      const tokenDecodificado: any = jwt_decode(token);
      localStorage.setItem('id', tokenDecodificado.sub);
    }



  getUsuarioList(): Observable<Usuario[]> {
    return this.http.get<Usuario[]>(environment.apiUrl + '/usuario');
  }


  register(usuario: Registro): Observable<Usuario> {
    console.log(usuario)
    return this.http.post<Usuario>(environment.signUpUrl, usuario)
  }

  update(updateUsuario: Usuario): Observable<Usuario> {
    let id = updateUsuario.usuarioId;
    return this.http.put<Usuario>(environment.apiUrl + '/usuario' +  `/${id}`, updateUsuario)
  }

  delete(id: number): Observable<Usuario> {
    return this.http.delete<Usuario>(environment.apiUrl + '/usuario' + `/${id}`)
  }


  updateEstados(){
      //return this.http.put(environment.apiUrl + '/usuario/estado')
      console.log("En construcción")
  }


  logout() {
    localStorage.clear()
    this.router.navigate(['/login'])
  }
}


