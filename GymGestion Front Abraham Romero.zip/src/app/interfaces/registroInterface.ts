export interface Registro{

    nombre: string
    apellidos: string
    nickname: string
    password: string;
}