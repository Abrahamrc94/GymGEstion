export interface Usuario{

    usuarioId?:number;
    nombre: string;
    apellidos: string;
	puntos: number;
	fecha_Proximo_Pago: string;
    nickname: string;
    password: string;
    estado: string;
}