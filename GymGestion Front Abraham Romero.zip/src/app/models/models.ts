import { Usuario } from '../interfaces/usuarioInterface'

export class UsuarioModal implements Usuario{

    id?:number;
    nombre: string
    apellidos: string
	puntos: number
	fecha_Proximo_Pago: string
    username: string
    password: string;


    constructor(
        id:number = null,
        nombre: string = null,
        apellidos: string = null,
        puntos: number = null,
        fecha_Proximo_Pago: string = null,
        username: string = null,
        password: string = null
    ){
        this.id = id;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.puntos = puntos;
        this.fecha_Proximo_Pago = fecha_Proximo_Pago;
        this.username = username;
        this.password = password;
    }
}

