import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Usuario } from '../interfaces/usuarioInterface';
import { Registro } from '../interfaces/registroInterface';
import { UsuarioService } from '../services/usuario.service';

@Component({
  selector: 'app-usuario-modal',
  templateUrl: './usuario-modal.component.html',
  styleUrls: ['./usuario-modal.component.scss']
})
export class UsuarioModalComponent implements OnInit {
  public form: FormGroup;

  public submitted = false;

  @Input() showModal: boolean;
  @Input() usuario: Usuario;
  @Output() close: EventEmitter<boolean> = new EventEmitter();
  @Output() newUsuario: EventEmitter<Usuario> = new EventEmitter();

  constructor(
    private formBuilder: FormBuilder,
    private usuarioService: UsuarioService
  ) {}

  ngOnInit() {
    this.createForm();
  }

  closeModal() {
    this.form.reset({ password: 'Gym1234' });
    this.submitted = false;
    this.close.emit(false);
  }

  onSubmit() {
    this.submitted = true;

    const fields = this.form.value;

    if (this.usuario.usuarioId) {
      this.update(fields);
    } else {
      this.register(fields);
    }
  }

  register(values: any) {

    const usuario: Registro = values;

    this.usuarioService.register(usuario).subscribe(
      (resp) => {
        this.newUsuario.emit(resp);
        this.closeModal()
      },
      (err) => {
        console.log(err);
      }
    );
  }

  update(values: any) {

    const { password, ...fields } = values;

    const updateUsuario: Usuario = fields;
    updateUsuario.usuarioId=this.usuario.usuarioId;

    this.usuarioService.update(updateUsuario).subscribe(
      (resp) => {
        this.newUsuario.emit(resp);
        this.closeModal()
      },
      (err) => {
        console.log(err);
      }
    );
  }

  createForm() {
    this.form = this.formBuilder.group({
      nombre: [
        '',
        [
          Validators.required,
          Validators.maxLength(45),
          Validators.minLength(2),
        ],
      ],
      apellidos: [
        '',
        [
          Validators.required,
          Validators.maxLength(70),
          Validators.minLength(2),
        ],
      ],
      nickname: ['', [Validators.required]],
      password: [
        'Gym1234',
        [
          Validators.required,
          Validators.pattern(/^(?=\w*\d)(?=\w*[A-Z])(?=\w*[a-z])\S*$/),
        ],
      ],
      puntos: ['', [Validators.required]],
    });
  }

  get f() {
    return this.form.controls;
  }

  public errorMessages = {
    name: [
      { type: 'required', message: 'The name is required' },
      { type: 'maxlength', message: 'Maximum 45 characters' },
      { type: 'minlength', message: 'Minimun 2 characters' },
    ],
    lastName: [
      { type: 'required', message: 'The name is required' },
      { type: 'maxlength', message: 'Maximum 70 characters' },
      { type: 'minlength', message: 'Minimun 2 characters' },
    ],
    email: [
      { type: 'required', message: 'The email is required' },
      { type: 'email', message: 'Must be a valid email' },
    ],
    role: [{ type: 'required', message: 'The role is required' }],
    password: [
      { type: 'required', message: 'The password is required' },
      {
        type: 'pattern',
        message:
          'Password must contain at least one lowercase letter, one uppercase letter, and one number',
      },
    ],
    language: [{ type: 'required', message: 'The language is required' }],
  };
}
